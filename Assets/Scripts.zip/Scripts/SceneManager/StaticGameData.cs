using UnityEngine;

public class StaticGameData : MonoBehaviour
{
    public static string playerName;
    public static int playerScore;

}
