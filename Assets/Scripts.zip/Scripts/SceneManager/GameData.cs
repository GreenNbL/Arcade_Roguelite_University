using UnityEngine;

[System.Serializable]
public class GameData
{
    public string playerName;
    public int playerScore;

}
